//
//  ViewController.swift
//  deneme1
//
//  Created by Nursema Nakiboğlu on 14.04.2022.
//

import UIKit

class ViewController: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.navigationItem.title = "NECKLACE"
        
        let appearence = UINavigationBarAppearance()
        
        //arka plan rengi
        appearence.backgroundColor = UIColor(named: "anaRenk")
        
        //Başlık rengi
        appearence.titleTextAttributes = [.foregroundColor : UIColor(named: "yaziRenk1")!,NSAttributedString.Key.font:UIFont(name: "RubikMoonrocks-Regular", size: 30)!]
        
        //Status bar
        navigationController?.navigationBar.barStyle = .black
        
        navigationController?.navigationBar.isTranslucent = true // seçilen renkleri gerçek tonuyla göstermek
        
        navigationController?.navigationBar.standardAppearance
        = appearence
        navigationController?.navigationBar.compactAppearance
        = appearence
        navigationController?.navigationBar.scrollEdgeAppearance
        = appearence
    }


}

